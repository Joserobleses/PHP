<!DOCTYPE html>
<html>
<head>
<title>Tasca M5 </title>
</head>
<body>

<h1>Nivel 3</h1>

<h2>Ejercicio 1 </h2>
<h3>Imprimeix per pantalla(valor a valor) l'array resultant del nivell anterior.</h3>

<?php
/* verificamos que se reciba valor de nivel2.php */

if( isset($_GET["variable"]) ){
/* recogemos valor de variable pasada por url */

$variable=$_GET['variable'];

/* convertimos variable de tipo string a array de nuevo*/
$array=explode(" ",$variable);

/* recorremos array e imprimimos uno a uno su valor mediante un bucle foreach */
foreach ($array as &$valor) {
    echo "<br />".$valor."<br />";
}

unset($valor); // rompe la referencia con el último elemento
}else{
    echo "debes ir a la página nivel2.php para recibir la variable del ejercicio anterior";
}
?>

<h2>Ejercicio 2 </h2>
<h3>Escriure un programa PHP que realitzi lo següent: declarar dues variables X e Y de tipus int, dues variables N i M de tipous double i assigna a cada una un valor. A continuació, mostra per pantalla, per a X e Y:</h3>
<ul>
<li>El valor de cada variable</li>
<li>La suma</li> 
<li>La resta</li> 
<li>El producte</li>  
<li>La divisió</li> 
<li>El mòdul</li>
</ul>
<?php
$x=10;
$y=20;
$n=1.5;
$m=2.5;

echo $x." e ".$y."<br>";
echo $x." + ".$y." = ".$x+$y."<br>";
echo $x." - ".$y." = ".$x-$y."<br>";
echo $x." * ".$y." = ".$x*$y."<br>";
echo $x." / ".$y." = ".$x/$y."<br>";
echo $x." % ".$y." = ".$x%$y."<br>";
echo "<br>";
echo $n." e ".$m."<br>";
echo $n." + ".$m." = ".$n+$m."<br>";
echo $n." - ".$m." = ".$n-$m."<br>";
echo $n." * ".$m." = ".$n*$m."<br>";
echo $n." / ".$m." = ".$n/$m."<br>";
echo $n." % ".$m." = ".$n%$m."<br>";
?>
<h3>per a N i M, lo mateix. I per a totes les variables(X,Y,N,M):</h3>
<?php
echo ($x*2)." ".($y*2)." ".($n*2)." ".($m*2)."<br>";
echo "<br>";
echo $x."+".$y."+".$n."+".$m." suman ".$x+$y+$n+$m."<br>";
echo "<br>";
echo $x."*".$y."*".$n."*".$m." dan como producto ".$x*$y*$n*$m."<br>";
?>
<ul>
<li>El doble de cada variable</li>
<li>La suma de totes les variables</li> 
<li>El producte de totes les variables</li> 
</ul>



<p><a href="index.php">Volver a p&aacute;gina a index.php</a></p>
<p><a href="nivel1.php">Enlace a nivel1.php</a></p>
<p><a href="nivel2.php">Enlace a nivel2.php</a></p>

</body>
</html>